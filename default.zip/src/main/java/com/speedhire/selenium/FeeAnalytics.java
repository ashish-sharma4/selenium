package com.speedhire.selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.sql.SQLOutput;
import java.util.ArrayList;
import java.util.List;

public class FeeAnalytics {

    public static List<String> findStudentsIdWithPendingFee(WebDriver driver, String studentPageUrl) {
        //Write your code here
    }
}
